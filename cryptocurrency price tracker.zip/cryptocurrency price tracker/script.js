
const apiEndpoint = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=inr";

function fetchCryptoData() {
    $.ajax({
        url: apiEndpoint,
        method: "GET",
        success: function (data) {
            populateTable(data);
        },
        error: function () {
            alert("Error fetching data. Please try again later.");
        },
    });
}

function populateTable(data) {
    const tableBody = $("#crypto-table");
    tableBody.empty();

    data.forEach((crypto) => {
        const row = `
      <tr>
        <td>${crypto.name}</td>
        <td>${crypto.symbol.toUpperCase()}</td>
        <td>₹${crypto.current_price.toLocaleString()}</td>
      </tr>
    `;
        tableBody.append(row);
    });
}


$("#search").on("input", function () {
    const searchText = $(this).val().toLowerCase();

    $("#crypto-table tr").each(function () {
        const rowText = $(this).text().toLowerCase();
        $(this).toggle(rowText.includes(searchText));
    });
});


$("#refresh").on("click", function () {
    fetchCryptoData();
});

$(document).ready(function () {
    fetchCryptoData();
});
