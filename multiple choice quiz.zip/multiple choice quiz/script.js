$(document).ready(function () {
    const apiUrl = "https://opentdb.com/api.php";
    let questions = [];
    let score = 0;

    $("#start-quiz").click(function () {
        const category = $("#category").val();
        const difficulty = $("#difficulty").val();

        $.ajax({
            url: apiUrl,
            method: "GET",
            data: {
                amount: 5,
                category: category,
                difficulty: difficulty,
                type: "multiple",
            },
            success: function (data) {
                questions = data.results;
                displayQuestions(questions);
            },
            error: function () {
                alert("Error fetching quiz questions. Please try again.");
            },
        });
    });

    function displayQuestions(questions) {
        $("#quiz-content").show();
        const questionsContainer = $("#questions");
        questionsContainer.empty(); // Clear old questions

        questions.forEach((question, index) => {
            const answers = [...question.incorrect_answers, question.correct_answer];
            shuffleArray(answers);

            const questionHtml = `
          <div class="question">
            <h3>Q${index + 1}: ${question.question}</h3>
            ${answers
                    .map(
                        (answer) => `
              <label>
                <input type="radio" name="question${index}" value="${answer}">
                ${answer}
              </label>
            `
                    )
                    .join("")}
          </div>
        `;
            questionsContainer.append(questionHtml);
        });

        $("#submit-quiz").show();
    }

    $("#submit-quiz").click(function () {
        score = 0;

        questions.forEach((question, index) => {
            const selectedAnswer = $(`input[name="question${index}"]:checked`).val();
            if (selectedAnswer === question.correct_answer) {
                score++;
            }
        });

        displayScore(score);
    });
    function displayScore(score) {
        $("#quiz-content").hide();
        $("#score").show();
        $("#score-value").text(score);
    }

    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }
});
